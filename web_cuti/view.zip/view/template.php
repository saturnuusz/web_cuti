<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="http://localhost/oopmvc/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="http://localhost/oopmvc/assets/bootstrap/js/bootstrap.min.js" rel="stylesheet">
    <title>web cuti</title>
</head>
<body>
    <div class="container">
    <?= $isi ?>
    </div>
</body>
</html>